/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mgestorv.facade;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import mgestorv.entity.DetalleVenta;
import mgestorv.entity.Venta;

/**
 *
 * @author dieoviedo
 */
@Stateless
public class DetalleVentaFacade extends AbstractFacade<DetalleVenta> {
    @PersistenceContext(unitName = "mgestorventasPU")
    private EntityManager em;
    
    private Connection connection;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DetalleVentaFacade() {
        super(DetalleVenta.class);
    }
    
    public void registrarDetalleVenta(Venta venta, List<DetalleVenta> lista) throws SQLException, Exception {
        
        this.connection = DataConnect.getConnection();
        this.connection.setAutoCommit(false);
        java.sql.Date sqlDate = new java.sql.Date(venta.getFechaVenta().getTime());
            
        PreparedStatement ps_3 = 
                this.connection.prepareStatement("INSERT INTO venta (id, fecha_venta, id_cliente, monto_total, ci_empleado) VALUES (?, ?, ?, ?, ?)");
        ps_3.setInt(1, venta.getId());
        ps_3.setDate(2, sqlDate);
        ps_3.setInt(3, venta.getIdCliente().getId());
        ps_3.setInt(4, venta.getMontoTotal());
        ps_3.setInt(5, venta.getCiEmpleado().getCi());
        ps_3.executeUpdate();
        ps_3.close();
            
        int stockActual = 0;
        for (DetalleVenta det : lista){
            PreparedStatement ps_2 = 
                this.connection.prepareStatement("INSERT INTO detalle_venta (cantidad, precio, id_producto, id_venta) VALUES (?, ?, ?, ?)");
            ps_2.setInt(1, det.getCantidad());
            ps_2.setInt(2, det.getPrecio());
            ps_2.setInt(3, det.getDetalleVentaPK().getIdProducto());
            ps_2.setInt(4, venta.getId());
            ps_2.executeUpdate();
            ps_2.close();
                
            PreparedStatement ps_5
                = this.connection.prepareStatement("SELECT stock_actual FROM producto WHERE id = ?");
            ps_5.setInt(1, det.getDetalleVentaPK().getIdProducto());
            ResultSet rs = ps_5.executeQuery();
                
            while (rs.next()) {
                Integer x = rs.getInt("stock_actual");
                stockActual = x.intValue();
            }
            
            //System.out.println(stockActual);
            
            if (stockActual < det.getCantidad()){
                throw new Exception("La cantidad determinada supera al Stock Actual del Producto");
            }else if(stockActual <= 1){
                throw new Exception("Se ha llegado al Stock Mínimo de 1 unidad, favor verificar producto");
            }
            
               
            PreparedStatement ps_4 = 
                    this.connection.prepareStatement("UPDATE producto set stock_actual = ? WHERE id = ?");
            ps_4.setInt(1, stockActual - det.getCantidad());
            ps_4.setInt(2, det.getDetalleVentaPK().getIdProducto());
            ps_4.executeUpdate();
            ps_4.close();
        }
        this.connection.commit();

        DataConnect.close(connection);

    }
}