/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import mgestorv.entity.Cliente;
import mgestorv.entity.DetalleVenta;
import mgestorv.entity.Empleado;
import mgestorv.entity.Producto;
import mgestorv.entity.Venta;
import mgestorv.facade.ClienteFacade;
import mgestorv.facade.DetalleVentaFacade;
import mgestorv.facade.EmpleadoFacade;
import mgestorv.facade.ProductoFacade;
import mgestorv.facade.VentaFacade;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;

/**
 *
 * @author dieoviedo
 */
@Named("agregarVentasController")
@ViewScoped
public class AgregarVentasController implements Serializable {

    private String nroVenta;
    private String fechaVenta;
    private Connection connection = null;
    
    private List<Cliente> clienteList = new ArrayList<Cliente>(); //comboClientes
    private List<Empleado> empleadoList = new ArrayList<Empleado>(); //comboVendedores
    private List<Producto> productoList = new ArrayList<Producto>(); //comboProducto
    private ArrayList<DetalleVenta> listaDetalle = new ArrayList<DetalleVenta>();
    private List<Venta> ventaList = new ArrayList<Venta>(); //listaVenta
    private List<DetalleVenta> detalleVentaList = new ArrayList<DetalleVenta>(); //listaVenta

    @Inject
    private ClienteFacade clienteFacade;
    @Inject
    private EmpleadoFacade empleadoFacade;
    @Inject
    private ProductoFacade productoFacade;
    @Inject
    private VentaFacade ventaFacade;
    @Inject
    private DetalleVentaFacade detalleVentaFacade;

    private Integer idCliente;
    private Empleado empleado;
    private Producto producto; //creas aca tu producto
    private DetalleVenta detalleVenta;
    private Cliente cliente;
    private Venta venta;
    private int cantidad = 0;
    private int montoTotal = 0;

    @PostConstruct
    void initialiseSession() {
        connection = DataConnect.getConnection();
        this.cargarVista();
        
    }

    //Se debe de tener en cuenta que todos los empleados de esta empresa son
    //Vendedores, por ende en el valor del campo descripcion_cargo,
    //estara 'Vendedor', más adelante cuando se quiera clasificar por 
    //descripcion del cargo ver la forma de filtrar los empleados
    //por este campo.
    private void cargarVista() {
        int nuevaSeq = obtenerNroVenta() + 1; //ultimo numero de venta + 1
        if (nuevaSeq < 10) {
            this.nroVenta = "000" + String.valueOf(nuevaSeq);
        } else if (nuevaSeq < 100) {
            this.nroVenta = "00" + String.valueOf(nuevaSeq);
        } else {
            this.nroVenta = String.valueOf(nuevaSeq);
        }

        Date date = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String today = formatter.format(date);
        fechaVenta = today;
        this.clienteList = clienteFacade.findAll();
        this.empleadoList = empleadoFacade.findAll();
        this.productoList = productoFacade.findAll();
    }
    
    //Este metodo obtiene el ultimo numero de venta
    private int obtenerNroVenta() {
        int ultimoValor = 0;
        try {
            PreparedStatement ps
                    = connection.prepareStatement("SELECT id FROM venta ORDER BY id DESC LIMIT 1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BigDecimal uv = rs.getBigDecimal("id");
                ultimoValor = uv.toBigInteger().intValue();
            }
            
        } catch (SQLException ex) {
            System.out.println("Error al obtener la secuencia -->" + ex.getMessage());
        }
        return ultimoValor;
    }
    
    public boolean isEmpty(Object obj){
        if (obj == null){
            return true;
        }
        return false;
    }
    
    public void agregarProducto() {
        
        try{
            if (this.isEmpty(this.producto)){
                throw new Exception("¡Campo Producto vacío!");
            }
            
            if (this.isEmpty(this.cliente)){
                throw new Exception("¡Campo Cliente vacío!");
            }
            
            if (this.isEmpty(this.empleado)){
                throw new Exception("¡Campo Vendedor vacío!");
            }
            
            if (this.cantidad == 0){
                throw new Exception("¡Campo Cantidad vacío, diferente de cero (0)!");
            }
            
            if (this.cantidad > 100){
                throw new Exception("¡Campo Cantidad ha excedidio el límite de 100 productos!");
            }
            int precio = this.calcularPrecio();
            
            this.montoTotal = precio + this.montoTotal;
            DetalleVenta dv = new DetalleVenta(this.producto.getId(), Integer.valueOf(this.nroVenta), 
                                               this.cantidad, precio);
            
            this.getDetalleVentaList().add(dv);
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,"Aviso", e.getMessage()));
        }     
    }
    
    
    public void registrarVenta() throws Exception{
        int montoTotal = 0;
        Date date = Calendar.getInstance().getTime();
        try{
            for(DetalleVenta det : detalleVentaList){
                montoTotal += det.getPrecio();
            }
            venta = new Venta(Integer.valueOf(this.nroVenta), date, montoTotal, this.cliente, this.empleado);
            this.detalleVentaFacade.registrarDetalleVenta(venta, detalleVentaList);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,"Aviso", "Registro Exitoso!"));
        }catch(Exception e){
            //throw e;
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"Aviso", "Error!")); 
        }finally{
            FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);
        }
    }
    
    /*
    public void cancelarVenta(){
        
        
        this.cargarVista();
    }

    */
    public Integer calcularPrecio (){
        int precio;
        precio = this.cantidad * this.producto.getPrecioUnitario();
        return precio;
    }

    public String getNroVenta() {
        return nroVenta;
    }

    public void setNroVenta(String nroVenta) {
        this.nroVenta = nroVenta;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public List<Cliente> getClienteList() {
        return clienteList;
    }

    public void setClienteList(List<Cliente> clienteList) {
        this.clienteList = clienteList;
    }

    public List<Empleado> getEmpleadoList() {
        return empleadoList;
    }

    public void setEmpleadoList(List<Empleado> empleadoList) {
        this.empleadoList = empleadoList;
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public List<Producto> getProductoList() {
        return productoList;
    }

    public void setProductoList(List<Producto> productoList) {
        this.productoList = productoList;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public List<Venta> getVentaList() {
        return ventaList;
    }

    public void setVentaList(List<Venta> ventaList) {
        this.ventaList = ventaList;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta Venta) {
        this.venta = Venta;
    }

    public List<DetalleVenta> getDetalleVentaList() {
        return detalleVentaList;
    }

    public void setDetalleVentaList(List<DetalleVenta> detalleVentaList) {
        this.detalleVentaList = detalleVentaList;
    }

    public DetalleVenta getDetalleVenta() {
        return detalleVenta;
    }

    public void setDetalleVenta(DetalleVenta detalleVenta) {
        this.detalleVenta = detalleVenta;
    }

    public ArrayList<DetalleVenta> getListaDetalle() {
        return listaDetalle;
    }

    public void setListaDetalle(ArrayList<DetalleVenta> listaDetalle) {
        this.listaDetalle = listaDetalle;
    }

    public int getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal() {
        this.montoTotal += this.calcularPrecio();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    
    
}
