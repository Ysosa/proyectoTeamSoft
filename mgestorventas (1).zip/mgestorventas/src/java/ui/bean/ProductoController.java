package ui.bean;

import mgestorv.entity.Producto;
import javax.inject.Named;
import javax.faces.view.ViewScoped;

@Named(value = "productoController")
@ViewScoped
public class ProductoController extends AbstractController<Producto> {

    public ProductoController() {
        // Inform the Abstract parent controller of the concrete Producto Entity
        super(Producto.class);
    }

}
