package ui.bean;

import mgestorv.entity.Localidad;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

@Named(value = "localidadController")
@ViewScoped
public class LocalidadController extends AbstractController<Localidad> {

    public LocalidadController() {
        // Inform the Abstract parent controller of the concrete Localidad Entity
        super(Localidad.class);
    }

    /**
     * Sets the "items" attribute with a collection of Cliente entities that are
     * retrieved from Localidad?cap_first and returns the navigation outcome.
     *
     * @return navigation outcome for Cliente page
     */
    public String navigateClienteCollection() {
        if (this.getSelected() != null) {
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("Cliente_items", this.getSelected().getClienteCollection());
        }
        return "/entity/cliente/index";
    }

}
