/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui.bean;

import java.io.Serializable;
import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import mgestorv.entity.Usuario;
import mgestorv.facade.UsuarioFacade;

/**
 *
 * @author dieoviedo
 */
@Named(value = "loginController")
@ViewScoped
public class LoginController implements Serializable{
    
    private Usuario usuario;
    
    @EJB
    private UsuarioFacade ejbUsuario;
    
    @PostConstruct
    public void init(){
        usuario = new Usuario();
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public String login(){
        Usuario u;
        String redireccion = null;
        try{
            u = ejbUsuario.login(usuario);
            if(u != null){
                redireccion = "/index?faces-redirect=true";  
            }else{
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Credenciales Incorrectas"));
            } 
        }catch(Exception e){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Aviso", "Error!"));
            throw e;
        }
        
        return redireccion;
    }
    

}
